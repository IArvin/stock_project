# -*-coding:utf-8-*-
import logging
from logging.handlers import TimedRotatingFileHandler
import json
import requests
import time
import xlrd
import xlwt
from pyquery import PyQuery as pq


# createTime: 2017-9-28 11:52:41
# 巨潮资讯相关数据下载


def config_log():
    fmt = '%(asctime)s - %(threadName)s - %(levelname)s - %(message)s'
    log = logging.getLogger('')
    fileTimeHandler = TimedRotatingFileHandler('JCZXScrapy.log', "D", 1, 3)
    fileTimeHandler.suffix = "%Y%m%d"
    fileTimeHandler.setFormatter(logging.Formatter(fmt))
    logging.basicConfig(level=logging.DEBUG, format=fmt)
    log.addHandler(fileTimeHandler)


class JCZXScrapy():
    def __init__(self):
        self.session = requests.session()
        self.timeout = 12

    def write_excel(self, data_list):
        excel = xlwt.Workbook()
        sheet01 = excel.add_sheet('demo_01')
        for index, tr in enumerate(data_list):
            sheet01.write(index, 0, tr['company_name'])
            sheet01.write(index, 1, tr['title'])
            sheet01.write(index, 2, tr['stock_id'])
            sheet01.write(index, 3, tr['file_size'])
            sheet01.write(index, 4, tr['time'])
        excel.save('demo.xls')
        return None

    def search(self):
        index_page = self.session.get('http://www.cninfo.com.cn/cninfo-new/index', timeout=self.timeout)

        params = {
            "searchkey": "问询",
            "sdate": "",
            "edate": "",
            "isfulltext": "false",
            "sortName": "nothing",
            "sortType": "desc",
            "pageNum": "1"
        }
        search_page = {}
        try:
            search_page = self.session.get('http://www.cninfo.com.cn/cninfo-new/fulltextSearch/full', params=params, timeout=self.timeout).json()
        except Exception, e:
            logging.info(e)

        data_list = []
        for tr in search_page['announcements']:
            data_dict = {}
            data_dict['company_name'] = tr['secName']
            data_dict['title'] = tr['announcementTitle']
            data_dict['stock_id'] = tr['secCode']
            data_dict['file_size'] = tr['adjunctSize']
            data_dict['time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(str(tr['announcementTime'])[:-3])))
            self.savePDF(tr['adjunctUrl'], tr['secCode'])
            data_list.append(data_dict)
        return data_list

    def savePDF(self, pdf_url, stock_id):
        url = 'http://www.cninfo.com.cn/'
        pdf_response = ''
        try:
            pdf_response = self.session.get(url+pdf_url, timeout=self.timeout)
        except Exception, e:
            logging.info(e)
        if pdf_response == '':
            logging.info('request failed, no response, return None')
            return 'failed'
        f = open(stock_id+'_'+pdf_url.split('/')[-2]+'.PDF', 'wb')
        f.write(pdf_response.content)
        f.close()
        logging.info('save success, return ...')
        return 'success'

    def main(self):
        data_list = self.search()
        self.write_excel(data_list)
        return None


if __name__ == '__main__':
    config_log()
    result = JCZXScrapy()
    result.main()
